# ye pagination ke liy import kiya gya h
# from rest_framework.pagination import PageNumberPagination
# from rest_framework.pagination import LimitOffsetPagination
from rest_framework.pagination import CursorPagination


# class MyPageNumberPagination(PageNumberPagination):
# class MylimitPagination(LimitOffsetPagination):
class MyCursorPagination(CursorPagination):

    # pagenumberpagination ke liy h
    # page_size = 5
    # page_query_param = 'p'
    # page_size_param = 'records'
    # max_size = 7
    # pass


# or ye limitoffsetpagination ke liy h
    # default_limit = 5
    # limit_query_param = 'mylimit'
    # offset_query_param = 'myoffset'
    # max_limit = 6

    #ye cursor pagination ke liy 
    page_size = 10
    ordering = 'name'
